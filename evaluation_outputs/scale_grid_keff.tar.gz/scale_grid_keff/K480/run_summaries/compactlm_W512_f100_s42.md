# CompactLM Direct Checkpoint Evaluation

- Model: `compactlm_W512_f100_s42`
- Checkpoint: `/home/sbbaik/Sentilight_Paper_2/Implement_New_Android_v6/backend/models/compact_llm/scale_grid_runs_keff/K480/W512/seed_42/f100/sft/compactlm_from_scratch_best.pt`
- Dataset: `/home/sbbaik/Sentilight_Paper_2/Implement_New_Android_v6/backend/models/compact_llm/datasets/keff_series/K480/test_rule.jsonl`
- Segment: `rule`
- Rows: `2000`
- Parameters: `37593600`
- Per-row JSONL: `/home/sbbaik/Sentilight_Paper_2/Implement_New_Android_v6/backend/reports/scale_grid_keff/K480/per_row/compactlm_W512_f100_s42.jsonl`

| Success | Strict | Coarse | Mean Latency | P95 Latency |
|---:|---:|---:|---:|---:|
| 2000/2000 | 1216 (60.80%) | 1778 (88.90%) | 212.01 | 223.61 |
