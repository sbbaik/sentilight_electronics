# CompactLM Direct Checkpoint Evaluation

- Model: `compactlm_W192_f100_s44`
- Checkpoint: `/home/sbbaik/Sentilight_Paper_2/Implement_New_Android_v6/backend/models/compact_llm/scale_grid_runs_keff/K48/W192/seed_44/f100/sft/compactlm_from_scratch_best.pt`
- Dataset: `/home/sbbaik/Sentilight_Paper_2/Implement_New_Android_v6/backend/models/compact_llm/datasets/keff_series/K48/test_rule.jsonl`
- Segment: `rule`
- Rows: `2000`
- Parameters: `8150208`
- Per-row JSONL: `/home/sbbaik/Sentilight_Paper_2/Implement_New_Android_v6/backend/reports/scale_grid_keff/K48/per_row/compactlm_W192_f100_s44.jsonl`

| Success | Strict | Coarse | Mean Latency | P95 Latency |
|---:|---:|---:|---:|---:|
| 1996/2000 | 969 (48.45%) | 1150 (57.50%) | 218.35 | 231.2 |
