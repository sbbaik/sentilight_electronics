# CompactLM Direct Checkpoint Evaluation

- Model: `compactlm_W384_f100_s46`
- Checkpoint: `/home/sbbaik/Sentilight_Paper_2/Implement_New_Android_v6/backend/models/compact_llm/scale_grid_runs_keff/K960/W384/seed_46/f100/sft/compactlm_from_scratch_best.pt`
- Dataset: `/home/sbbaik/Sentilight_Paper_2/Implement_New_Android_v6/backend/models/compact_llm/datasets/keff_series/K960/test_rule.jsonl`
- Segment: `rule`
- Rows: `2000`
- Parameters: `23378304`
- Per-row JSONL: `/home/sbbaik/Sentilight_Paper_2/Implement_New_Android_v6/backend/reports/scale_grid_keff/K960/per_row/compactlm_W384_f100_s46.jsonl`

| Success | Strict | Coarse | Mean Latency | P95 Latency |
|---:|---:|---:|---:|---:|
| 2000/2000 | 1430 (71.50%) | 1796 (89.80%) | 254.04 | 265.34 |
