# CompactLM Direct Checkpoint Evaluation

- Model: `compactlm_D3_f100_s46`
- Checkpoint: `/home/sbbaik/Sentilight_Paper_2/Implement_New_Android_v6/backend/models/compact_llm/scale_grid_runs_depth_a2/D3/seed_46/f100/sft/compactlm_from_scratch_best.pt`
- Dataset: `/home/sbbaik/Sentilight_Paper_2/Implement_New_Android_v6/backend/models/compact_llm/datasets/keff_series/A2K192/test_rule.jsonl`
- Segment: `rule`
- Rows: `2000`
- Parameters: `14527104`
- Per-row JSONL: `/home/sbbaik/Sentilight_Paper_2/Implement_New_Android_v6/backend/reports/scale_grid_depth_a2_l3/per_row/compactlm_D3_f100_s46.jsonl`

| Success | Strict | Coarse | Mean Latency | P95 Latency |
|---:|---:|---:|---:|---:|
| 2000/2000 | 1467 (73.35%) | 1748 (87.40%) | 85.31 | 87.51 |
