# CompactLM Direct Checkpoint Evaluation

- Model: `compactlm_D3_f100_s42`
- Checkpoint: `/home/sbbaik/Sentilight_Paper_2/Implement_New_Android_v6/backend/models/compact_llm/scale_grid_runs_depth_a2/D3/seed_42/f100/sft/compactlm_from_scratch_best.pt`
- Dataset: `/home/sbbaik/Sentilight_Paper_2/Implement_New_Android_v6/backend/models/compact_llm/datasets/keff_series/A2K192/test_rule.jsonl`
- Segment: `rule`
- Rows: `2000`
- Parameters: `14527104`
- Per-row JSONL: `/home/sbbaik/Sentilight_Paper_2/Implement_New_Android_v6/backend/reports/scale_grid_depth_a2_l3/per_row/compactlm_D3_f100_s42.jsonl`

| Success | Strict | Coarse | Mean Latency | P95 Latency |
|---:|---:|---:|---:|---:|
| 2000/2000 | 1362 (68.10%) | 1566 (78.30%) | 93.01 | 97.72 |
