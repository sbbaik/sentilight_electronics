# CompactLM Direct Checkpoint Evaluation

- Model: `compactlm_W192_f100_s45`
- Checkpoint: `/home/sbbaik/Sentilight_Paper_2/Implement_New_Android_v6/backend/models/compact_llm/scale_grid_runs_keff_fs/K480/W192/seed_45/f100/sft/compactlm_from_scratch_best.pt`
- Dataset: `/home/sbbaik/Sentilight_Paper_2/Implement_New_Android_v6/backend/models/compact_llm/datasets/keff_series/K480/test_rule.jsonl`
- Segment: `rule`
- Rows: `2000`
- Parameters: `8150208`
- Per-row JSONL: `/home/sbbaik/Sentilight_Paper_2/Implement_New_Android_v6/backend/reports/scale_grid_keff_fs/K480/per_row/compactlm_W192_f100_s45.jsonl`

| Success | Strict | Coarse | Mean Latency | P95 Latency |
|---:|---:|---:|---:|---:|
| 2000/2000 | 1052 (52.60%) | 1426 (71.30%) | 208.04 | 236.46 |
