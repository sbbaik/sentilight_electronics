# CompactLM Direct Checkpoint Evaluation

- Model: `compactlm_W192_f100_s46`
- Checkpoint: `/home/sbbaik/Sentilight_Paper_2/Implement_New_Android_v6/backend/models/compact_llm/scale_grid_runs_keff_fs/K480/W192/seed_46/f100/sft/compactlm_from_scratch_best.pt`
- Dataset: `/home/sbbaik/Sentilight_Paper_2/Implement_New_Android_v6/backend/models/compact_llm/datasets/keff_series/K480/test_rule.jsonl`
- Segment: `rule`
- Rows: `2000`
- Parameters: `8150208`
- Per-row JSONL: `/home/sbbaik/Sentilight_Paper_2/Implement_New_Android_v6/backend/reports/scale_grid_keff_fs/K480/per_row/compactlm_W192_f100_s46.jsonl`

| Success | Strict | Coarse | Mean Latency | P95 Latency |
|---:|---:|---:|---:|---:|
| 2000/2000 | 1012 (50.60%) | 1398 (69.90%) | 209.68 | 238.35 |
