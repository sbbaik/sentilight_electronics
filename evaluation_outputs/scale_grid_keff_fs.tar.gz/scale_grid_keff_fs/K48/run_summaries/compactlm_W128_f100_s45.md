# CompactLM Direct Checkpoint Evaluation

- Model: `compactlm_W128_f100_s45`
- Checkpoint: `/home/sbbaik/Sentilight_Paper_2/Implement_New_Android_v6/backend/models/compact_llm/scale_grid_runs_keff_fs/K48/W128/seed_45/f100/sft/compactlm_from_scratch_best.pt`
- Dataset: `/home/sbbaik/Sentilight_Paper_2/Implement_New_Android_v6/backend/models/compact_llm/datasets/keff_series/K48/test_rule.jsonl`
- Segment: `rule`
- Rows: `2000`
- Parameters: `4679808`
- Per-row JSONL: `/home/sbbaik/Sentilight_Paper_2/Implement_New_Android_v6/backend/reports/scale_grid_keff_fs/K48/per_row/compactlm_W128_f100_s45.jsonl`

| Success | Strict | Coarse | Mean Latency | P95 Latency |
|---:|---:|---:|---:|---:|
| 2000/2000 | 1155 (57.75%) | 1543 (77.15%) | 209.57 | 240.71 |
