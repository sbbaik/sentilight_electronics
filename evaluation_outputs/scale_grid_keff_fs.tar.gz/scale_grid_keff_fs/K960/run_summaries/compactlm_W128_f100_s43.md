# CompactLM Direct Checkpoint Evaluation

- Model: `compactlm_W128_f100_s43`
- Checkpoint: `/home/sbbaik/Sentilight_Paper_2/Implement_New_Android_v6/backend/models/compact_llm/scale_grid_runs_keff_fs/K960/W128/seed_43/f100/sft/compactlm_from_scratch_best.pt`
- Dataset: `/home/sbbaik/Sentilight_Paper_2/Implement_New_Android_v6/backend/models/compact_llm/datasets/keff_series/K960/test_rule.jsonl`
- Segment: `rule`
- Rows: `2000`
- Parameters: `4679808`
- Per-row JSONL: `/home/sbbaik/Sentilight_Paper_2/Implement_New_Android_v6/backend/reports/scale_grid_keff_fs/K960/per_row/compactlm_W128_f100_s43.jsonl`

| Success | Strict | Coarse | Mean Latency | P95 Latency |
|---:|---:|---:|---:|---:|
| 2000/2000 | 1161 (58.05%) | 927 (46.35%) | 197.31 | 207.51 |
