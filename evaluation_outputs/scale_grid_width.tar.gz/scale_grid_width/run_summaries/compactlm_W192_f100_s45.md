# CompactLM Direct Checkpoint Evaluation

- Model: `compactlm_W192_f100_s45`
- Checkpoint: `/home/sbbaik/Sentilight_Paper_2/Implement_New_Android_v6/backend/models/compact_llm/scale_grid_runs_width/W192/seed_45/f100/sft/compactlm_from_scratch_best.pt`
- Dataset: `/home/sbbaik/Sentilight_Paper_2/Implement_New_Android_v6/backend/models/compact_llm/datasets/keff_series/K240/test_rule.jsonl`
- Segment: `rule`
- Rows: `2000`
- Parameters: `8150208`
- Per-row JSONL: `/home/sbbaik/Sentilight_Paper_2/Implement_New_Android_v6/backend/reports/scale_grid_width/per_row/compactlm_W192_f100_s45.jsonl`

| Success | Strict | Coarse | Mean Latency | P95 Latency |
|---:|---:|---:|---:|---:|
| 2000/2000 | 855 (42.75%) | 1477 (73.85%) | 205.94 | 223.87 |
