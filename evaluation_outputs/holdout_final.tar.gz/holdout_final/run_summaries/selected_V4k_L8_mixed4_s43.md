# CompactLM Direct Checkpoint Evaluation

- Model: `selected_V4k_L8_mixed4_s43`
- Checkpoint: `/home/sbbaik/Sentilight_Paper_2/Implement_New_Android_v6/backend/models/compact_llm/scale_grid_runs_vocab_natural_q4/V4k_s43_mixed4.pt`
- Dataset: `/home/sbbaik/Sentilight_Paper_2/Implement_New_Android_v6/backend/models/compact_llm/datasets/holdout_natural/K240/holdout_2000.jsonl`
- Segment: `rule`
- Rows: `2000`
- Parameters: `15698304`
- Per-row JSONL: `/home/sbbaik/Sentilight_Paper_2/Implement_New_Android_v6/backend/reports/holdout_final/per_row/selected_V4k_L8_mixed4_s43.jsonl`

| Success | Strict | Coarse | Mean Latency | P95 Latency |
|---:|---:|---:|---:|---:|
| 2000/2000 | 882 (44.10%) | 1397 (69.85%) | 102.24 | 107.8 |
