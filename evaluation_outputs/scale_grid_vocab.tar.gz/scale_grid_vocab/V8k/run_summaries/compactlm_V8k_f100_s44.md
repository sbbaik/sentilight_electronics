# CompactLM Direct Checkpoint Evaluation

- Model: `compactlm_V8k_f100_s44`
- Checkpoint: `/home/sbbaik/Sentilight_Paper_2/Implement_New_Android_v6/backend/models/compact_llm/scale_grid_runs_vocab/V8k/V8k/seed_44/f100/sft/compactlm_from_scratch_best.pt`
- Dataset: `/home/sbbaik/Sentilight_Paper_2/Implement_New_Android_v6/backend/models/compact_llm/datasets/keff_series/K240/test_rule.jsonl`
- Segment: `rule`
- Rows: `2000`
- Parameters: `17234304`
- Per-row JSONL: `/home/sbbaik/Sentilight_Paper_2/Implement_New_Android_v6/backend/reports/scale_grid_vocab/V8k/per_row/compactlm_V8k_f100_s44.jsonl`

| Success | Strict | Coarse | Mean Latency | P95 Latency |
|---:|---:|---:|---:|---:|
| 2000/2000 | 790 (39.50%) | 1282 (64.10%) | 190.35 | 195.57 |
