# CompactLM Direct Checkpoint Evaluation

- Model: `compactlm_V16k_f100_s43`
- Checkpoint: `/home/sbbaik/Sentilight_Paper_2/Implement_New_Android_v6/backend/models/compact_llm/scale_grid_runs_vocab/V16k/V16k/seed_43/f100/sft/compactlm_from_scratch_best.pt`
- Dataset: `/home/sbbaik/Sentilight_Paper_2/Implement_New_Android_v6/backend/models/compact_llm/datasets/keff_series/K240/test_rule.jsonl`
- Segment: `rule`
- Rows: `2000`
- Parameters: `20306304`
- Per-row JSONL: `/home/sbbaik/Sentilight_Paper_2/Implement_New_Android_v6/backend/reports/scale_grid_vocab/V16k/per_row/compactlm_V16k_f100_s43.jsonl`

| Success | Strict | Coarse | Mean Latency | P95 Latency |
|---:|---:|---:|---:|---:|
| 2000/2000 | 622 (31.10%) | 1066 (53.30%) | 209.72 | 229.83 |
