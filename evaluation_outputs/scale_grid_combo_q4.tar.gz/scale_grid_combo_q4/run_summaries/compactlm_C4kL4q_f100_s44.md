# CompactLM Direct Checkpoint Evaluation

- Model: `compactlm_C4kL4q_f100_s44`
- Checkpoint: `/home/sbbaik/Sentilight_Paper_2/Implement_New_Android_v6/backend/models/compact_llm/scale_grid_runs_combo_q4/C4kL4_s44_mixed4.pt`
- Dataset: `/home/sbbaik/Sentilight_Paper_2/Implement_New_Android_v6/backend/models/compact_llm/datasets/keff_series/K240/test_rule.jsonl`
- Segment: `rule`
- Rows: `2000`
- Parameters: `8617344`
- Per-row JSONL: `/home/sbbaik/Sentilight_Paper_2/Implement_New_Android_v6/backend/reports/scale_grid_combo_q4/per_row/compactlm_C4kL4q_f100_s44.jsonl`

| Success | Strict | Coarse | Mean Latency | P95 Latency |
|---:|---:|---:|---:|---:|
| 2000/2000 | 1022 (51.10%) | 1827 (91.35%) | 59.13 | 65.25 |
