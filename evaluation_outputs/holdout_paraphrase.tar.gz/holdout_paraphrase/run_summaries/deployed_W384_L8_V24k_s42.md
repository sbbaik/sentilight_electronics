# CompactLM Direct Checkpoint Evaluation

- Model: `deployed_W384_L8_V24k_s42`
- Checkpoint: `/home/sbbaik/Sentilight_Paper_2/Implement_New_Android_v6/backend/models/compact_llm/scale_grid_runs_width/W384/seed_42/f100/sft/compactlm_from_scratch_best.pt`
- Dataset: `/home/sbbaik/Sentilight_Paper_2/Implement_New_Android_v6/backend/models/compact_llm/datasets/holdout_paraphrase/K240/holdout_paraphrase.jsonl`
- Segment: `rule`
- Rows: `2000`
- Parameters: `23378304`
- Per-row JSONL: `/home/sbbaik/Sentilight_Paper_2/Implement_New_Android_v6/backend/reports/holdout_paraphrase/per_row/deployed_W384_L8_V24k_s42.jsonl`

| Success | Strict | Coarse | Mean Latency | P95 Latency |
|---:|---:|---:|---:|---:|
| 2000/2000 | 255 (12.75%) | 428 (21.40%) | 213.39 | 220.28 |
