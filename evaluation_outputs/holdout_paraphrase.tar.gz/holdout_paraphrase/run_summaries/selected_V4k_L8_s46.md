# CompactLM Direct Checkpoint Evaluation

- Model: `selected_V4k_L8_s46`
- Checkpoint: `/home/sbbaik/Sentilight_Paper_2/Implement_New_Android_v6/backend/models/compact_llm/scale_grid_runs_vocab_natural/V4k/V4k/seed_46/f100/sft/compactlm_from_scratch_best.pt`
- Dataset: `/home/sbbaik/Sentilight_Paper_2/Implement_New_Android_v6/backend/models/compact_llm/datasets/holdout_paraphrase/K240/holdout_paraphrase.jsonl`
- Segment: `rule`
- Rows: `2000`
- Parameters: `15698304`
- Per-row JSONL: `/home/sbbaik/Sentilight_Paper_2/Implement_New_Android_v6/backend/reports/holdout_paraphrase/per_row/selected_V4k_L8_s46.jsonl`

| Success | Strict | Coarse | Mean Latency | P95 Latency |
|---:|---:|---:|---:|---:|
| 2000/2000 | 291 (14.55%) | 500 (25.00%) | 201.48 | 207.24 |
