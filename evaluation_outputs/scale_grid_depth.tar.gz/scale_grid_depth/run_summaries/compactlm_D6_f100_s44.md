# CompactLM Direct Checkpoint Evaluation

- Model: `compactlm_D6_f100_s44`
- Checkpoint: `/home/sbbaik/Sentilight_Paper_2/Implement_New_Android_v6/backend/models/compact_llm/scale_grid_runs_depth/D6/seed_44/f100/sft/compactlm_from_scratch_best.pt`
- Dataset: `/home/sbbaik/Sentilight_Paper_2/Implement_New_Android_v6/backend/models/compact_llm/datasets/keff_series/K240/test_rule.jsonl`
- Segment: `rule`
- Rows: `2000`
- Parameters: `19837824`
- Per-row JSONL: `/home/sbbaik/Sentilight_Paper_2/Implement_New_Android_v6/backend/reports/scale_grid_depth/per_row/compactlm_D6_f100_s44.jsonl`

| Success | Strict | Coarse | Mean Latency | P95 Latency |
|---:|---:|---:|---:|---:|
| 2000/2000 | 982 (49.10%) | 1733 (86.65%) | 161.7 | 172.25 |
