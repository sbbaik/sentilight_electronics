# Frozen manifest — post hoc LLM-paraphrased synthetic stress set

Frozen 2026-09-13. 2000 released rows; 3838 unique candidates; 2600 accepted by blind back-labelling (67.7 %); 1238 rejected with reasons.

| file | sha256 | bytes |
|---|---|--:|
| accepted.jsonl | `fa1281ebae5917c105a150500b5d766217e3af0bd744fac681d3eeeb62cd857c` | 442,496 |
| candidates.jsonl | `9da52fdaf05e0390c9037d978f0b1dfee253254462a49c6900082532dbda78df` | 640,373 |
| holdout_paraphrase.jsonl | `cff61e8ac08a9e403ff645b7867ea908272c0ed6a06023f724d9335a4fd941c2` | 1,774,147 |
| rejected.jsonl | `a768a3b3b85c4222f93e929f9c464509ae0685caeb5818414bcb63da1ab272c9` | 250,420 |
| report.md | `ff6bd6dc1bbfc7c88921e143e8bde63a6331a157c45f344d71028eec67d6aadc` | 1,239 |
| prompts.json | `ae5353c196cf92dbdaaf79835751fd7a3fb7a51d24c42b9b6358c79f45dca89d` | 6,524 |

Raw API responses preserved: 432 files in `raw_api_responses/` (generation and back-labelling replies as returned; no credentials).

Generator: gemini-3.1-flash-lite, Gemini API, called 2026-09-13 KST, temperature 1.0 for generation and 0.0 for back-labelling, 432 calls.
The API key was read from an environment variable at run time and appears in no output, log, report or release file.
