# 패러프레이즈 홀드아웃 저자 확인용 표본 (60행)

생성 모델이 만든 문장과 정책이 부여한 정답이 맞는지 저자가 확인한다. 색·감정·강도 중 하나라도 문장과 어긋나면 '아니오'로 표시한다.

| # | 문장 | 목표 색 | 목표 감정 | 목표 강도 | 정답 튜플 | 맞는가 | 메모 |
|--:|---|---|---|---|---|---|---|
| 1 | 아니, 지금 빛이 너무 강해서 짜증 난다고. 좀 부드러운 오렌지 빛으로 조도를 대폭 낮춰주면 안 돼? 진짜 참기 힘드네. | orange | anger | soft | H 25, S 78, B 80, Dimmer 76, CT 248 |  |  |
| 2 | 가슴이 먹먹해서 버티기가 힘드네. 지금 당장 가장 힘 있는 강도로 켜 줘. | - | sadness | strong | H 222, S 46, B 32, Dimmer 30, CT 400 |  |  |
| 3 | 강렬한 다홍빛으로 방 안을 꽉 채워주세요. 아주 평온한 기분이에요. | red | calm | strong | H 5, S 80, B 74, Dimmer 72, CT 290 |  |  |
| 4 | 창밖 노을 같은 색감으로 공간을 옅게 물들이고 싶어. 지금 너무 밝아서 조금만 더 차분하게 빛을 덜어내 줘. | orange | calm | dark | H 29, S 60, B 40, Dimmer 36, CT 333 |  |  |
| 5 | 가슴이 떨려 미치겠는데 레몬색으로 설정해. | yellow | anxiety | neutral | H 53, S 58, B 52, Dimmer 48, CT 305 |  |  |
| 6 | 무서워, 불 좀 주황빛으로 어둡게 해줘. | orange | anxiety | dark | H 24, S 52, B 18, Dimmer 12, CT 353 |  |  |
| 7 | 우울해서 빛마저 눈부신 게 싫어. 파란색으로 최대한 연하고 은근하게 조절해 주겠어? | blue | sadness | soft | H 213, S 26, B 20, Dimmer 12, CT 500 |  |  |
| 8 | 텅 빈 마음이 너무 힘들어. 선명한 청록색으로 아주 밝게 불 좀 켜줘. 어둠이 무서워. | green | sadness | bright | H 117, S 50, B 48, Dimmer 44, CT 402 |  |  |
| 9 | 라일락 꽃 색깔로 빛을 내고 밝기를 최대한 끌어올려서 방 안을 빈틈없이 환하게 비춰주는 설정을 적용해 줘. | purple | - | bright | H 286, S 80, B 78, Dimmer 76, CT 332 |  |  |
| 10 | 지금부터 거실에 배치된 조명기구의 색상을 잘 익은 곶감의 색상과 동일하게 맞춰주기 바랍니다. | orange | - | neutral | H 28, S 90, B 78, Dimmer 76, CT 250 |  |  |
| 11 | 너무 울적해. 핏빛으로 아주 진하게 켜줘. | red | sadness | strong | H 358, S 74, B 46, Dimmer 42, CT 335 |  |  |
| 12 | 너무 울어서 눈이 아파. 가장 환하게 좀 해줘. | - | sadness | bright | H 221, S 40, B 40, Dimmer 38, CT 402 |  |  |
| 13 | 어두컴컴한 녹색으로 해주면 조금 나을 것 같아. 지금 너무 불안해서 미치겠거든. | green | anxiety | dark | H 116, S 36, B 8, Dimmer 2, CT 423 |  |  |
| 14 | 따뜻한 태양 빛을 닮은 색상으로 조명 설정을 변경 부탁드립니다. | yellow | - | neutral | H 55, S 88, B 82, Dimmer 80, CT 240 |  |  |
| 15 | 침실 조명을 좀 어두운 개나리색 느낌으로 조정해 주길 바란다. | yellow | - | dark | H 53, S 80, B 52, Dimmer 48, CT 278 |  |  |
| 16 | 마음 다스리게 밝은 청색 불로 바꿔. | blue | calm | bright | H 224, S 60, B 72, Dimmer 70, CT 447 |  |  |
| 17 | 오늘따라 마음이 참 벅차오르네, 내 공간을 하얀 빛으로 채워서 이 기분을 만끽하고 싶어. | white | happiness | neutral | H 47, S 12, B 98, Dimmer 98, CT 260 |  |  |
| 18 | 기분이 너무 저기압이라 힘드네. 그냥 방을 보라색으로 맞춰두고 싶어. | purple | sadness | neutral | H 281, S 48, B 26, Dimmer 22, CT 430 |  |  |
| 19 | 밝은 청색으로 해줘. 가슴이 너무 먹먹해서 견디기 힘들다. | blue | sadness | bright | H 217, S 54, B 44, Dimmer 40, CT 492 |  |  |
| 20 | 사람 화나게 하지 말고 당장 보랏빛으로 불을 좀 죽여봐. 도대체 언제까지 이렇게 환하게 둘 거야? | purple | anger | dark | H 283, S 80, B 42, Dimmer 40, CT 358 |  |  |
| 21 | 무슨 소리가 나는 것 같아서 너무 겁나요. 빛이 있으면 더 불안하니까 지금 바로 아주 어둡게 조절해주세요. | - | anxiety | dark | H 208, S 22, B 0, Dimmer 0, CT 433 |  |  |
| 22 | 공기가 차갑게 느껴져서 불안해요. 방 안을 아주 밝은 주광색 조명으로 꽉 채워주시겠어요? | white | anxiety | bright | H 44, S 0, B 70, Dimmer 68, CT 342 |  |  |
| 23 | 너무 신나니까 조명을 아주 강렬한 퍼플 컬러로 바꿔줄래? | purple | happiness | strong | H 289, S 92, B 84, Dimmer 82, CT 305 |  |  |
| 24 | 아니, 지금 눈부시게 밝은 라벤더색으로 안 바꾸냐? | purple | anger | bright | H 286, S 92, B 88, Dimmer 88, CT 312 |  |  |
| 25 | 내 슬픔을 다 담을 수 있게, 아주 선명하고 짙은 푸른빛으로 방을 물들여줘. | blue | sadness | strong | H 218, S 60, B 36, Dimmer 32, CT 490 |  |  |
| 26 | 좋은 일 생겼어! 지금보다 훨씬 환한 청량한 푸른 빛 부탁해. | blue | happiness | bright | H 223, S 88, B 94, Dimmer 92, CT 377 |  |  |
| 27 | 지금 거실에 있는 조명 색깔을 청명한 가을 하늘을 닮은 색으로 바꿔줘. | blue | - | neutral | H 220, S 78, B 64, Dimmer 62, CT 410 |  |  |
| 28 | 아 짜증 나게 왜 이리 어두워! 당장 밝게, 풀숲 같은 초록색으로 바꿔. | green | anger | bright | H 121, S 90, B 94, Dimmer 94, CT 292 |  |  |
| 29 | 지금 당장 보랏빛으로 바꿔! 아까부터 말했잖아, 내 말이 말 같지 않아? | purple | anger | neutral | H 285, S 88, B 72, Dimmer 72, CT 320 |  |  |
| 30 | 진짜 성질 뻗치네. 그냥 하얀색으로 해, 더 말하게 하지 말고. | white | anger | neutral | H 45, S 18, B 94, Dimmer 96, CT 265 |  |  |
| 31 | 진짜 사람 화나게 만드네. 방 안을 온통 짙은 보랏빛으로, 아주 강렬하게 꽉 채워버려. | purple | anger | strong | H 287, S 98, B 80, Dimmer 80, CT 310 |  |  |
| 32 | 머리 아파서 미치겠으니까 당장 조명 좀 낮춰. 노을처럼 희미한 주황빛으로 설정하라고. 왜 이렇게 앱을 멍청하게 만들어놨어? 짜증 나게. | orange | anger | soft | H 25, S 78, B 80, Dimmer 76, CT 248 |  |  |
| 33 | 지금 정신이 하나도 없어. 강렬한 황금빛 주황색으로 밝기 최대치로 올려줘. | orange | anxiety | strong | H 28, S 70, B 56, Dimmer 52, CT 305 |  |  |
| 34 | 마음이 붕 떠서 말이야. 붉은 빛을 아주 약하고 부드럽게 조절해 줄래? | red | happiness | soft | H 359, S 74, B 80, Dimmer 74, CT 248 |  |  |
| 35 | 조금 더 묵직하고 밀도 있게 해 주면 좋겠는데 가능한가? | - | - | strong | H 47, S 30, B 64, Dimmer 64, CT 290 |  |  |
| 36 | 너무 초조해서 그래. 제발 노란 계열로 어둡게 만들어줘. | yellow | anxiety | dark | H 51, S 50, B 22, Dimmer 16, CT 343 |  |  |
| 37 | 지금 당장 보라색으로 최대 출력 내놔. 열받으니까. | purple | anger | strong | H 287, S 98, B 80, Dimmer 80, CT 310 |  |  |
| 38 | 좋은 일이 생겨서 가슴이 벅차올라. 내 마음을 대변하듯 공간을 아주 훤하게 비춰줘. | - | happiness | bright | H 39, S 82, B 100, Dimmer 100, CT 227 |  |  |
| 39 | 마치 잘 익은 감을 닮은 색상으로 조명을 변경하고, 빛의 세기는 은은한 수준으로 맞춰. | orange | - | soft | H 25, S 66, B 70, Dimmer 64, CT 268 |  |  |
| 40 | 이별 후유증 때문에 너무 힘드네. 장미꽃 같은 색으로 설정해. | red | sadness | neutral | H 356, S 64, B 38, Dimmer 34, CT 345 |  |  |
| 41 | 조용히 사색에 잠기고 싶으니, 흐릿함 없이 모든 구석을 또렷하고 짙게 메워주길 바랄게. | - | calm | strong | H 187, S 52, B 66, Dimmer 68, CT 305 |  |  |
| 42 | 최대한 강렬한 빨간색으로 맞춰줘. 지금 너무 행복해서 미칠 것 같아! | red | happiness | strong | H 4, S 100, B 96, Dimmer 94, CT 220 |  |  |
| 43 | 지금 내 기분처럼 부드럽고 따스한 노을빛 조명을 부탁해. | red | calm | soft | H 0, S 46, B 58, Dimmer 52, CT 318 |  |  |
| 44 | 조명 좀 보라색으로 팍 낮춰줘. 지금 너무 초조해서 미칠 것 같아. | purple | anxiety | dark | H 281, S 38, B 2, Dimmer 0, CT 443 |  |  |
| 45 | 슬픔을 잊고 싶어서 그래. 아주 강렬하고 밝은 루비색 조명을 켜줘. | red | sadness | bright | H 357, S 68, B 54, Dimmer 50, CT 337 |  |  |
| 46 | 세상 모든 게 다 내 편인 것 같아! 지금 이 환희가 그대로 느껴지도록 최고치로 묵직하게 밝혀줘. | - | happiness | strong | H 40, S 88, B 96, Dimmer 94, CT 225 |  |  |
| 47 | 지금보다 조금 더 몽글몽글한 느낌으로 빛을 줄여봐. | - | - | soft | H 42, S 0, B 48, Dimmer 44, CT 318 |  |  |
| 48 | 오늘 하루 종일 기분이 너무 좋았어. 황혼의 주황색으로 은은하게 방을 채워주면 완벽할 것 같아. | orange | happiness | soft | H 27, S 72, B 84, Dimmer 78, CT 243 |  |  |
| 49 | 불그스름한 색감이 나게 하고 조명 세기를 지금보다 더 어둡게 만들어 주면 좋겠어. | red | - | dark | H 358, S 84, B 44, Dimmer 40, CT 293 |  |  |
| 50 | 내가 아까부터 말했잖아, 어두운 건 딱 질색이라고! 밝기는 제일 높게 올리고, 색깔은 눈이 시릴 정도로 쨍한 초록색으로 좀 맞춰보라고, 진짜 사람 짜증 나게 하지 말고. | green | anger | bright | H 121, S 90, B 94, Dimmer 94, CT 292 |  |  |
| 51 | 아니 진짜 짜증 나게 왜 이렇게 밝아? 얼른 어둡게 좀 해봐. | - | anger | dark | H 10, S 84, B 42, Dimmer 44, CT 293 |  |  |
| 52 | 마음이 안 놓여서 그래. 그냥 창백한 하얀색으로 아주 어둡게 조정해주라. | white | anxiety | dark | H 41, S 0, B 24, Dimmer 20, CT 388 |  |  |
| 53 | 와, 대박! 진짜 최고다. 이 행복한 기분을 만끽하게 조도를 확 줄여서 아늑하게 만들어 주겠니? | - | happiness | dark | H 36, S 70, B 58, Dimmer 54, CT 273 |  |  |
| 54 | 하얀색으로 좀 바꿔줘, 지금 너무 불안해서 죽겠어. | white | anxiety | neutral | H 43, S 0, B 54, Dimmer 52, CT 350 |  |  |
| 55 | 마치 고요한 밤의 운무처럼 신비한 보라색으로 방을 물들여줄래? 지금 내 기분이 무척 차분해. | purple | calm | neutral | H 288, S 54, B 54, Dimmer 52, CT 385 |  |  |
| 56 | 마음이 안 잡히는데, 쨍한 거 말고 부드러운 파란색으로 은근하게 해줘. | blue | anxiety | soft | H 215, S 24, B 26, Dimmer 18, CT 493 |  |  |
| 57 | 마음이 공허해서 견딜 수가 없네요. 제발 최대치로 밝혀주세요. | - | sadness | bright | H 221, S 40, B 40, Dimmer 38, CT 402 |  |  |
| 58 | 오늘따라 기분이 정말 날아갈 것 같아. 은근하고 어스름한 보라색 조명으로 바꿔서 나만의 아늑한 휴식 공간을 만들어줘. | purple | happiness | dark | H 285, S 74, B 46, Dimmer 42, CT 353 |  |  |
| 59 | 도저히 견딜 수 없이 슬퍼. 장미보다 더 새빨갛고 진한 빛이 필요해. | red | sadness | strong | H 358, S 74, B 46, Dimmer 42, CT 335 |  |  |
| 60 | 보라색으로 최대한 찐하게! 밝기 최대로! 지금 당장! | purple | anger | strong | H 287, S 98, B 80, Dimmer 80, CT 310 |  |  |
