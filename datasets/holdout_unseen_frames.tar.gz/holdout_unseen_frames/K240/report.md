# Final hold-out test set (K240 production policy)

- rows: 2000; seed 20260913; sha256 b5b7ee711e749eed033632676bb6751ec678962aeda9c431cfa8e2149368166b
- reachable tuples covered: 240/240; min rows per tuple 2; max 20
- exact-string overlap with any K-series train/val/test utterance: 0
- sources: {'holdout_mixed': 1436, 'holdout_color_only': 256, 'holdout_emotion_only': 225, 'holdout_fallback': 83}
- sentence frames: 32 new frames in 6 families (frames.json); none appears in the generator's training, validation, development-test or fill templates
- intensity is named in every non-neutral row; gold tuples computed by the executable policy (0 ambiguity by construction)
- this file was created after all model selection was complete (2026-09-13) and is used once, for the final evaluation reported in the paper
