# Unseen-frame synthetic hold-out (K240 production policy)

**Naming.** The directory is named `holdout_natural` for historical reasons (it was created to contrast with the
template-heavy training splits). The set is **not** a collection of natural human utterances. Every row was generated
from one of 32 sentence frames written for this purpose, using the policy's own category lexicon, and the gold tuple is
computed by the executable policy. The manuscript calls it the **unseen-frame synthetic hold-out** and never claims it
measures generalisation to spontaneous human speech.

**What it does and does not establish.**
- It does establish generalisation across *sentence frames*: none of the 32 frames, and no utterance string, occurs in
  any training, validation or development-test file of any K-series policy (0 exact-string overlaps, checked over all
  such files).
- It does not establish generalisation to human-written utterances. Rows within a frame are near-variants of each other,
  so the 2,000 rows are not 2,000 independent linguistic samples. Analyses therefore use a cluster bootstrap over
  seeds -> frames (within family) -> rows, and per-frame accuracy is reported (`tables/T15_holdout_frame_families.csv`).

**Contents.** 2,000 rows; 32 frames in 6 families (`frames.json`); all 240 reachable tuples present, minimum 2 rows per
tuple; sources mixed 1,436 / colour-only 256 / emotion-only 225 / fallback 83; non-neutral intensity is named in every
non-neutral row. Built 2026-09-13, after all model selection was complete, and used once.

Files: `holdout_2000.jsonl` (sha256 in `holdout_2000.sha256`), `frames.json`, `report.md`, this README.
Builder: `tools/build_holdout_natural.py`.
